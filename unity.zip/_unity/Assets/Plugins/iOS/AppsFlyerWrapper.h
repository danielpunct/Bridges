//
//  AppsFlyerWarpper.h
//  
//
//  Created by AppsFlyer 2013
//
//

#import <UIKit/UIKit.h>
#import "AppsFlyerDelegate.h"

@interface AppsFlyerWarpper : NSObject 


+(AppsFlyerDelegate *) getAppsFlyerDelegate;

@end
